import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-analytics.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  getFirestore, doc, getDoc, setDoc, updateDoc, collection, addDoc, getDocs, query, orderBy, limit, deleteDoc, onSnapshot, serverTimestamp, writeBatch, where 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD-9zZzfheMpd71Tn74oTyKTeCld_-RBU4",
  authDomain: "al-driven-crime-anal-lbbcplfo.firebaseapp.com",
  projectId: "al-driven-crime-anal-lbbcplfo",
  storageBucket: "al-driven-crime-anal-lbbcplfo.firebasestorage.app",
  messagingSenderId: "258283061207",
  appId: "1:258283061207:web:ee834f3f21a0f6cf0ad592",
  measurementId: "G-44XKXV7FLF"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const db = getFirestore(app);

// Make them available globally
window.firebaseApp = app;
window.firebaseAnalytics = analytics;
window.firebaseAuth = auth;
window.firebaseDb = db;

// Expose Firestore SDK utilities
window.firestoreDb = {
  db,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  addDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  deleteDoc,
  onSnapshot,
  serverTimestamp,
  writeBatch
};

// Global auth helper functions
window.signInWithGoogle = () => signInWithPopup(auth, googleProvider);
window.signOutFromFirebase = () => signOut(auth);
window.onAuthStateChangedListener = (callback) => onAuthStateChanged(auth, callback);
window.signInWithEmail = (email, password) => signInWithEmailAndPassword(auth, email, password);
window.signUpWithEmail = (email, password) => createUserWithEmailAndPassword(auth, email, password);

console.log("Firebase Auth & Firestore system initialized successfully:", app);

